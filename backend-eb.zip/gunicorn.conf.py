# bind provided via CLI in entrypoint (see entrypoint.sh)
# bind = "0.0.0.0:8000"
workers = 3
worker_class = "gthread"
threads = 4
timeout = 120
graceful_timeout = 30
accesslog = "-"
errorlog = "-"
loglevel = "info"
