import os
import uuid
import logging
import boto3
from botocore.exceptions import BotoCoreError, ClientError
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from .serializers import PresignRequestSerializer

logger = logging.getLogger(__name__)


class PresignUploadView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        s = PresignRequestSerializer(data=request.data)
        if not s.is_valid():
            logger.info("presign.invalid %s", s.errors)
            return Response({"error": s.errors}, status=status.HTTP_400_BAD_REQUEST)

        data = s.validated_data
        bucket = os.environ.get("S3_MEDIA_BUCKET", os.environ.get("AWS_STORAGE_BUCKET_NAME", ""))
        # Prefer AWS_S3_REGION_NAME consistent with django-storages; fallback to AWS_REGION
        region = os.environ.get("AWS_S3_REGION_NAME", os.environ.get("AWS_REGION", "us-east-1"))
        logger.info("presign.request user=%s property_id=%s filename=%s ctype=%s region=%s",
                    getattr(request.user, 'id', None), data.get('property_id'), data.get('filename'), data.get('content_type'), region)
        if not bucket:
            logger.error("presign.misconfig missing bucket env")
            return Response({"error": "misconfigured", "message": "Missing S3 bucket env (S3_MEDIA_BUCKET or AWS_STORAGE_BUCKET_NAME)"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        key = f"properties/{data['property_id']}/{uuid.uuid4().hex}-{data['filename']}"
        try:
            s3 = boto3.client("s3", region_name=region)
            params = {
                "Bucket": bucket,
                "Key": key,
                "ContentType": data["content_type"],
                "CacheControl": "public, max-age=31536000, immutable",
            }
            upload_url = s3.generate_presigned_url(
                ClientMethod="put_object",
                Params=params,
                ExpiresIn=300,
                HttpMethod="PUT",
            )
            return Response({
                "upload_url": upload_url,
                "s3_key": key,
                "headers": {
                    "Content-Type": data["content_type"],
                    "Cache-Control": "public, max-age=31536000, immutable",
                }
            }, status=200)

        except (ClientError, BotoCoreError) as e:
            logger.exception(
                "presign.fail bucket=%s key=%s user=%s",
                bucket, key, getattr(request.user, 'id', None)
            )
            msg = getattr(e, "response", {}).get("Error", {}).get("Message", str(e))
            code = getattr(e, "response", {}).get("Error", {}).get("Code", "ClientError")
            return Response({"error": "s3_presign_failed", "code": code, "message": msg}, status=status.HTTP_502_BAD_GATEWAY)
        except Exception as e:
            logger.exception("presign.unexpected")
            return Response({"error": "unexpected", "message": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
