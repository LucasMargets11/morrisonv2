from rest_framework import serializers
import mimetypes
import re


class PresignRequestSerializer(serializers.Serializer):
    property_id = serializers.IntegerField(min_value=1)
    filename = serializers.CharField(max_length=255)
    content_type = serializers.CharField(max_length=100)

    def validate(self, attrs):
        ct = (attrs.get("content_type") or "").lower()
        if ct not in {"image/jpeg", "image/png", "image/webp"}:
            raise serializers.ValidationError({"content_type": "Tipo no permitido."})
        # Normalize/sanitize filename: drop paths, keep safe chars
        name = (attrs.get("filename") or "").split("/")[-1].split("\\")[-1]
        name = re.sub(r"[^A-Za-z0-9._-]", "_", name)
        # Try to fix content type when generic
        if not ct or ct == "application/octet-stream":
            guess, _ = mimetypes.guess_type(name)
            if guess:
                attrs["content_type"] = guess
        attrs["filename"] = name
        return attrs
